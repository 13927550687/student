$(document).ready(function() {
	var t = $('#editable').DataTable({
		"order": [
			[4, 'desc']
		],
		"pagingType": "full_numbers",
		"bProcessing": true,
		"columnDefs": [{
			//禁止排序
			"targets": [0, 6],
			"orderable": false
		}, {
			"targets": [4, 5, 6],
			"searchable": false
		}]
	});

	t.on('order.dt search.dt', function() {
		t.column(0, {
			"search": 'applied',
			"order": 'applied'
		}).nodes().each(function(cell, i) {
			cell.innerHTML = i + 1;
		});
	}).draw();
	//关闭加载条
	parent.NProgress.done();

	var hId = '';
	//查看
	$(document).on('click', '.get', function() {
		hId = $(this).attr('hId'); //获取id
		parent.NProgress.start();
		window.location.href = 'getIdHW?id=' + hId;
	})

})