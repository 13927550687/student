/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : student

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2019-04-03 18:32:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stunum` varchar(45) NOT NULL,
  `name` varchar(28) NOT NULL,
  `depart` varchar(35) NOT NULL,
  `claname` varchar(35) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '1721604433', '林俊辉', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('2', '17216032', '苏瑜均', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('3', '17216031', '吴国腾', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('4', '1721604436', '张志标', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('5', '1721604437', '黄日嘉', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('6', '1721604447', '李汉尧', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('7', '17216028', '林嘉明', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('8', '1721604401', '郑俊林', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('9', '1721604424', '陈嘉辉', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('10', '1721604431', '李宇聪', '软件教研室', '17级计算机程序设计高级4班');
INSERT INTO `student` VALUES ('11', '1721604402', '陈堃', '软件教研室', '17级计算机程序设计高级4班');
