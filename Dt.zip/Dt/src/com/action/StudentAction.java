package com.action;

import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import com.entity.Student;
import com.service.StudentService;

@Namespace("/index")
@Results({ //配置返回具体页面
	@Result(name="studentList", location="/index/student_list.jsp"),
	@Result(name="reuserList", type="redirect", location="studentList.action"),
})	
@SuppressWarnings("serial")// 为了消除serialVersionUID警告
public class StudentAction extends BaseAction{

	private List<Student> studentList;
	@Autowired
	private StudentService studentService;
	
	/*
	 * 列表
	 * return
	 */
	@Action("studentList")
	public String userList(){
		studentList = studentService.getList();
		return "studentList";
	}


	public List<Student> getStudentList() {
		return studentList;
	}


	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}


	public StudentService getStudentService() {
		return studentService;
	}


	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
}
