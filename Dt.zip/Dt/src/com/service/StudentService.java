package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.StudentDao;
import com.entity.Student;


@Service	//注释service层spring管理bean
@Transactional//注释所有方法放入spring事务管理
public class StudentService {
	@Autowired   //spring注入对象
	private StudentDao studentDao;
	
	/*
	 * 学生列表
	 */
	public List<Student> getList() {
		return studentDao.selectList();
	}
}
