package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Student;


@Repository 
public class StudentDao extends BaseDao {
     /*
      * 列表
      */
	public List<Student> selectList(){
		return getSession().createQuery("from Student order by id desc", Student.class).list();
	}
}
